const { request, response } = require('express');
var express = require('express');
var router = express.Router();


router.post("/approve",(request, response, next) => {
    
})


module.exports = router;
